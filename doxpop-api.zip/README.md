# Doxpop API Node.js

## Overview
This project is a Node.js implementation of the Doxpop API.

## Setup
To set up the project, follow these steps:
1. Clone the repository.
2. Run `npm install`.
3. Create a `.env` file with necessary environment variables.

## Usage
Run `node app.js` to start the server.

## Testing
Tests are yet to be implemented.

## Contributing
See `CONTRIBUTING.md` for guidelines.

## License
See `LICENSE` for more information.