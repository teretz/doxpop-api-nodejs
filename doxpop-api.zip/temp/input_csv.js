const { Logger } = require('./logger');
const logger = new Logger();
logger.init();

// Rest of the code
