// Configuration Utility

const config = {
  PORT: process.env.PORT || 3000,
  // Add other configuration variables here
};

module.exports = config;